package cs3500.hw03;

import java.io.Reader;
import java.util.List;

/**
 * Created by Gus on 5/26/2017.
 */

public class FreecellController implements IFreecellController {

  public FreecellController(Reader stringReader, StringBuffer out) {

  }

  @Override
  public void playGame(List deck, FreecellOperations model, int numCascades, int numOpens, boolean shuffle) {
    model.startGame(deck, numCascades, numOpens, shuffle);
    System.out.println(model.getGameState());
  }
}
