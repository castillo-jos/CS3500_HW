package cs3500.hw03;

import java.io.IOException;
import java.io.Reader;
import java.nio.CharBuffer;
import java.util.List;
import java.util.Scanner;

import cs3500.hw02.Card;
import cs3500.hw02.FreecellModel;
import cs3500.hw02.FreecellOperations;
import cs3500.hw02.PileType;

/**
 * Created by Gus on 5/26/2017.
 */

public class FreecellController implements IFreecellController {
  PlayerInput rd;
  GameOutput ap;
  FreecellModel model;
  List<Card> deck;
  PileType sourcePile;
  int pileNumber;
  int cardIndex;
  PileType destination;
  int destPileNumber;

  public FreecellController(Readable rd, Appendable ap) throws IllegalArgumentException {
    this.rd = (PlayerInput) rd;
    this.ap = (GameOutput) ap;
  }

  @Override
  public void playGame(List deck, FreecellOperations model, int numCascades, int numOpens, boolean shuffle) throws IllegalArgumentException {
    model.startGame(deck, numCascades, numOpens, shuffle);
    while(!model.isGameOver()){
      Scanner pInput = new Scanner(System.in);
      String nextMove = new String(pInput.next());
      CharBuffer cb = CharBuffer.allocate(nextMove.length());
      PlayerInput reader = new PlayerInput(nextMove);
      System.out.println(reader.read(cb));
      cb.flip();
      if(cb.get(0) == 'C'){
        sourcePile = PileType.CASCADE;
      }
      else if(cb.get(0) == 'O'){
        sourcePile = PileType.OPEN;
      }
      else if (cb.get(0) == 'q' || cb.get(0) == 'Q'){
        throw new IllegalArgumentException();
      }

      pileNumber = (int) (cb.get(1) -1);
      cardIndex = -1;
      if(cb.get(3) == 'C'){
        destination = PileType.CASCADE;
      }
      else if (cb.get(3) == 'O'){
        destination = PileType.OPEN;
      }
      else if(cb.get(3) == 'F'){
        destination = PileType.FOUNDATION;
      }
      else{
        throw new IllegalAccessError();
      }

      destPileNumber = (int) (cb.get(4) - 1);
      model.move(sourcePile, pileNumber, cardIndex, destination, destPileNumber);
      System.out.print(model.getGameState());
    }
  }
}
