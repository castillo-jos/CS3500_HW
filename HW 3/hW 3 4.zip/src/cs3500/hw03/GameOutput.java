package cs3500.hw03;

import java.io.IOException;

/**
 * Created by Gus on 5/27/2017.
 */
public class GameOutput implements Appendable {
  StringBuffer gOutput = new StringBuffer();

  public String toString(){
    return gOutput.toString();
  }

  @Override
  public Appendable append(CharSequence csq) throws IOException {
    gOutput.append(csq);
    return null;
  }

  @Override
  public Appendable append(CharSequence csq, int start, int end) throws IOException {
    return null;
  }

  @Override
  public Appendable append(char c) throws IOException {
    gOutput.append(c);
    return null;
  }
}
