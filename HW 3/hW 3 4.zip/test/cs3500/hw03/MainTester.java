package cs3500.hw03;

import java.io.IOException;
import java.nio.CharBuffer;
import java.util.List;

import cs3500.hw02.Card;
import cs3500.hw02.FreecellModel;

/**
 * Created by Gus on 5/27/2017.
 */
public class MainTester {
  public static void main(String[] args) throws IOException {
    PlayerInput rd = new PlayerInput("hello");
    GameOutput ap = new GameOutput();
    FreecellModel model = new FreecellModel();
    List<Card> deck = model.getDeck();
    FreecellController testOne = new FreecellController(rd, ap);
    testOne.playGame(deck, model, 8, 4, false);
  }
}

