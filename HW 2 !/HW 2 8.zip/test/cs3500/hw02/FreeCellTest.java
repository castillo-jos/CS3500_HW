package cs3500.hw02;

/**
 * Created by Gus on 5/20/2017.
 */
import org.junit.Test;

public class FreeCellTest {
  @Test
  public void deckTest(){

  }
}
