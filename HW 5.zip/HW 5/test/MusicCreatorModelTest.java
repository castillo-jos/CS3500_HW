import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

/**
 * Created by Gus on 6/8/2017.
 */
public class MusicCreatorModelTest {

  @Test
  public void equalsExample() {
    Note c4 = new Note("C", 4);
    Note g4 = new Note("G", 4);
    Note e3 = new Note("E", 3);
    Note f3 = new Note("F", 3);
    Note fSharp3 = new Note("F#", 3);
    Note g3 = new Note("G", 3);
    Note gSharp3 = new Note("G#", 3);
    Note a3 = new Note("A", 3);
    Note aSharp3 = new Note("A#", 3);
    Note b3 = new Note("B", 3);
    Note cSharp4 = new Note("C#", 4);
    Note d4 = new Note("D", 4);
    Note dSharp4 = new Note("D", 4);
    Note f4 = new Note("F", 4);
    Note fSharp4 = new Note("F#", 4);
    Note e4 = new Note("E", 4);
    MusicCreatorOperations model = new MusicCreatorModel();
    model.startCreator(e3, g4);
    model.addBeat(g3, 0, 7);
    model.addBeat(e4, 0, 2);
    model.addBeat(d4, 2, 2);
    model.addBeat(c4, 4, 2);
    model.addBeat(d4, 6, 2);
    model.addBeat(g3, 8, 7);
    model.addBeat(e4, 8, 2);
    model.addBeat(e4, 10, 2);
    model.addBeat(e4, 12, 3);
    model.addBeat(g3, 16, 10);
    model.addBeat(d4, 16, 2);
    model.addBeat(g3, 24, 2);
    model.addBeat(d4, 18, 2);
    model.addBeat(d4, 20, 4);
    model.addBeat(e4, 24, 2);
    model.addBeat(g4, 26, 2);
    model.addBeat(g4, 28, 4);
    model.addBeat(g3, 32, 8);
    model.addBeat(e4, 32, 2);
    model.addBeat(d4, 34, 2);
    model.addBeat(c4, 36, 2);
    model.addBeat(d4, 38, 2);
    model.addBeat(g3, 40, 8);
    model.addBeat(e4, 40, 2);
    model.addBeat(e4, 42, 2);
    model.addBeat(e4, 44, 2);
    model.addBeat(e4, 46, 2);
    model.addBeat(g3, 48, 8);
    model.addBeat(d4, 48, 2);
    model.addBeat(d4, 50, 2);
    model.addBeat(d4, 54, 2);
    model.addBeat(e4, 52, 2);
    model.addBeat(e3, 56, 8);
    model.addBeat(c4, 56, 8);
    assertEquals("    E3   F3  F#3   G3  G#3   A3  A#3   B3   C4  C#4   D4  D#4   E4   F4  F#4   G4 \n" +
                    " 0                 X                                            X                 \n" +
                    " 1                 |                                            |                 \n" +
                    " 2                 |                                  X                           \n" +
                    " 3                 |                                  |                           \n" +
                    " 4                 |                        X                                     \n" +
                    " 5                 |                        |                                     \n" +
                    " 6                 |                                  X                           \n" +
                    " 7                                                    |                           \n" +
                    " 8                 X                                            X                 \n" +
                    " 9                 |                                            |                 \n" +
                    "10                 |                                            X                 \n" +
                    "11                 |                                            |                 \n" +
                    "12                 |                                            X                 \n" +
                    "13                 |                                            |                 \n" +
                    "14                 |                                            |                 \n" +
                    "15                                                                                \n" +
                    "16                 X                                  X                           \n" +
                    "17                 |                                  |                           \n" +
                    "18                 |                                  X                           \n" +
                    "19                 |                                  |                           \n" +
                    "20                 |                                  X                           \n" +
                    "21                 |                                  |                           \n" +
                    "22                 |                                  |                           \n" +
                    "23                 |                                  |                           \n" +
                    "24                 X                                            X                 \n" +
                    "25                 |                                            |                 \n" +
                    "26                                                                             X  \n" +
                    "27                                                                             |  \n" +
                    "28                                                                             X  \n" +
                    "29                                                                             |  \n" +
                    "30                                                                             |  \n" +
                    "31                                                                             |  \n" +
                    "32                 X                                            X                 \n" +
                    "33                 |                                            |                 \n" +
                    "34                 |                                  X                           \n" +
                    "35                 |                                  |                           \n" +
                    "36                 |                        X                                     \n" +
                    "37                 |                        |                                     \n" +
                    "38                 |                                  X                           \n" +
                    "39                 |                                  |                           \n" +
                    "40                 X                                            X                 \n" +
                    "41                 |                                            |                 \n" +
                    "42                 |                                            X                 \n" +
                    "43                 |                                            |                 \n" +
                    "44                 |                                            X                 \n" +
                    "45                 |                                            |                 \n" +
                    "46                 |                                            X                 \n" +
                    "47                 |                                            |                 \n" +
                    "48                 X                                  X                           \n" +
                    "49                 |                                  |                           \n" +
                    "50                 |                                  X                           \n" +
                    "51                 |                                  |                           \n" +
                    "52                 |                                            X                 \n" +
                    "53                 |                                            |                 \n" +
                    "54                 |                                  X                           \n" +
                    "55                 |                                  |                           \n" +
                    "56  X                                       X                                     \n" +
                    "57  |                                       |                                     \n" +
                    "58  |                                       |                                     \n" +
                    "59  |                                       |                                     \n" +
                    "60  |                                       |                                     \n" +
                    "61  |                                       |                                     \n" +
                    "62  |                                       |                                     \n" +
                    "63  |                                       |                                     ",
            model.showSheetMusic());
  }

  @Test
  public void addingAndRemovingNotesTest(){
    MusicCreatorOperations model = new MusicCreatorModel();
    MusicCreatorOperations model1 = new MusicCreatorModel();

    Note c4 = new Note("C", 4);
    Note g6 = new Note("G", 6);
    model.startCreator(c4, g6);

    model1.addNote(c4);
    model1.addNote(g6);

    assertEquals(model.showSheetMusic(), model1.showSheetMusic());

    model1.removeLastNote();
    model1.removeFirstNote();

    assertNotEquals(model.showSheetMusic(), model1.showSheetMusic());

    Note cSharp4 = new Note("C#", 4);
    Note fSharp6 = new Note("F#", 6);
    MusicCreatorOperations model2 = new MusicCreatorModel();
    model2.startCreator(cSharp4,fSharp6);

    assertEquals(model1.showSheetMusic(), model2.showSheetMusic());
  }

  @Test
  public void addingAndRemovingBeatsTest(){
    MusicCreatorModel model = new MusicCreatorModel();
    MusicCreatorModel model1 = new MusicCreatorModel();

    Note c4 = new Note("C", 4);

    model.addNote(c4);
    model1.addNote(c4);
    model.addBeat(c4, 4,4);
    model1.addBeat(c4,4,4);
    assertEquals(model.showSheetMusic(), model1.showSheetMusic());

    model.removeBeat(c4,4);

    assertEquals(model.showSheetMusic(), "    C4 ");
  }

  @Test(expected = IllegalArgumentException.class)
  public void InvalidRemovingFirstNote(){
    MusicCreatorOperations model = new MusicCreatorModel();
    model.removeFirstNote();
  }

  @Test(expected = IllegalArgumentException.class)
  public void InvalidRemovingLastNote(){
    MusicCreatorOperations model = new MusicCreatorModel();
    model.removeLastNote();
  }

  @Test(expected = IllegalArgumentException.class)
  public void InvalidRemovingBeat(){
    Note c4 = new Note("C", 4);
    MusicCreatorOperations model = new MusicCreatorModel();
    model.removeBeat(c4, 4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void InvalidDuplicateAddingNote(){
    Note c4 = new Note("C", 4);
    MusicCreatorOperations model = new MusicCreatorModel();
    model.addNote(c4);
    model.addNote(c4);
  }
}
