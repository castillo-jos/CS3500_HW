package cs3500.hw04;

import cs3500.hw02.FreeCellModel;

/**
 * Created by Gus on 5/30/2017.
 */
public class FreeCellModelCreator {
  public enum GameType {
    SINGLEMOVE, MULTIMOVE
  }

  private FreeCellModelCreator() {

  }

  public static final FreeCellModel create(GameType type) {
    if (type == GameType.SINGLEMOVE) {
      return new FreeCellModel();
    }
    else{
      return new MultiFreeCellModel();
    }
  }
}
