package cs3500.hw03;

import java.nio.CharBuffer;
import java.util.Scanner;

import cs3500.hw02.FreecellModel;
import cs3500.hw02.FreecellOperations;
import cs3500.hw02.PileType;

/**
 * Created by Gus on 5/27/2017.
 */
public class PlayerInput implements Readable {

  public String input = new String();
  char[] commandOne;
  char[] commandTwo;
  PileType sourcePile;
  PileType destination;
  int pileNumber;
  int destPileNumber;
  FreecellOperations currentGame;


  PlayerInput(FreecellOperations currentGame) {
    this.currentGame = currentGame;
  }

  @Override
  public int read(CharBuffer cb) throws IllegalArgumentException {
    System.out.println("Give new command: " );
    Scanner pInput = new Scanner(System.in);
    String nextMove = new String(pInput.nextLine());
    String[] splited = nextMove.split("\\s+");

    if(splited.length == 1) {
      char[] commandOne = splited[0].toCharArray();
      if(commandOne[0] == 'q' || commandOne[0] == 'Q'){
        throw new IllegalArgumentException();
      }
    } else if(splited.length > 1 && splited.length < 3){
      commandOne = splited[0].toCharArray();
      commandTwo = splited[1].toCharArray();
    }else{
      throw new IllegalArgumentException();
    }

    if (commandOne[0] == 'C') {
      sourcePile = PileType.CASCADE;
    } else if (commandOne[0] == 'O') {
      sourcePile = PileType.OPEN;
    } else {
      throw new IllegalArgumentException();
    }

    pileNumber = (int) (Character.getNumericValue(commandOne[1] - 1));
    int cardIndex = 0;

    if (commandTwo[0] == 'C') {
      destination = PileType.CASCADE;
    } else if (commandTwo[0] == 'O') {
      destination = PileType.OPEN;
    } else if (commandTwo[0] == 'F') {
      destination = PileType.FOUNDATION;
    } else {
      throw new IllegalAccessError();
    }

    destPileNumber = (Character.getNumericValue(commandTwo[1] - 1));
    currentGame.move(sourcePile, pileNumber, cardIndex, destination, destPileNumber);
    return 0;
  }
}
