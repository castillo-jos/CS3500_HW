package cs3500.hw02;

/**
 * Created by Gus on 5/17/2017.
 */
public class Card {
  private String suit;
  private String value;


  public PileType cardIsInPile;

  /**
   * This builds the Card class, with suit and value and all.
   *
   * @param suit  the Suit of the card.
   * @param value the value of card.
   */
  public Card(String suit, String value) {
    setSuit(suit);
    setValue(value);
  }

  public String getSuit() {
    return this.suit;
  }

  public String getValue() {
    return this.value;
  }


  public void setSuit(String suit) {
    this.suit = suit;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public String toString() {
    return getValue() + getSuit();
  }
}
